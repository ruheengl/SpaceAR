using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    
    public enum GameState { PlacingStart, CreatingPlanets, PlacingFinish, Playing, GameOver, Victory }
    public GameState currentState = GameState.PlacingStart;
    
    [Header("Setup")]
    public GameObject astronaut;
    public int midAirPlanetsNeeded = 6;
    
    [Header("Lives")]
    public int maxLives = 7;
    public int currentLives;
    
    [Header("UI")]
    public TextMeshProUGUI livesText;
    public TextMeshProUGUI instructionText;
    public TextMeshProUGUI stateText;
    public GameObject victoryPanel;
    public GameObject gameOverPanel;
    
    [Header("Audio")]
    public AudioSource audioSource;
    public AudioClip planetSound;
    
    // Internal tracking
    public List<GameObject> planets = new List<GameObject>();
    private HashSet<int> visitedPlanets = new HashSet<int>();
    
    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }
    
    void Start()
    {
        currentLives = maxLives;
        astronaut.SetActive(false);
        victoryPanel.SetActive(false);
        gameOverPanel.SetActive(false);
        UpdateUI();
    }
    
    void Update()
    {
        UpdateInstructions();
    }
    
    void UpdateInstructions()
    {
        stateText.text = "State: " + currentState.ToString();
        
        switch (currentState)
        {
            case GameState.PlacingStart:
                instructionText.text = "TAP ground to place START planet";
                break;
                
            case GameState.CreatingPlanets:
                instructionText.text = "HOLD screen to create mid-air planet";
                break;
                
            case GameState.PlacingFinish:
                instructionText.text = "TAP ground to place FINISH planet";
                break;
                
            case GameState.Playing:
                instructionText.text = "HOLD near astronaut to jump!\nVisit all planets to win!";
                break;
        }
    }
    

    
    public void MarkPlanetVisited(int index)
    {
        if (!visitedPlanets.Contains(index))
        {
            visitedPlanets.Add(index);
            
            // Change color to green
            Renderer rend = planets[index].GetComponentInChildren<Renderer>();
            if (rend != null)
            {
                // 1. Get the planet's main (Albedo) color
                Color baseColor = rend.material.color;

                // 2. Set the emission to that color. 
                // You can multiply it to make it brighter (e.g., baseColor * 1.5f)
                rend.material.SetColor("_EmissionColor", baseColor);

                // 3. You still need to enable the emission keyword
                rend.material.EnableKeyword("_EMISSION");
            }
            
            Debug.Log("Planet " + index + " visited! Total: " + visitedPlanets.Count);
            
            // Check victory
            if (visitedPlanets.Count >= planets.Count)
            {
                Victory();
            }
        }
    }
    
    public void LoseLife()
    {
        currentLives--;
        UpdateUI();
        
        if (currentLives <= 0)
        {
            GameOver();
        }
    }
    
    void Victory()
    {
        currentState = GameState.Victory;
        victoryPanel.SetActive(true);
    }
    
    void GameOver()
    {
        currentState = GameState.GameOver;
        gameOverPanel.SetActive(true);
    }
    
    void UpdateUI()
    {
        livesText.text = "Lives: " + currentLives + "/" + maxLives;
    }
    
    public void RestartGame()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(
            UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex);
    }
}