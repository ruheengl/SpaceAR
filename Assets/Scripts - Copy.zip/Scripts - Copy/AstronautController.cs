using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;

public class AstronautController : MonoBehaviour
{
    [Header("Jump Settings")]
    public float minJumpDistance = 0.5f;
    public float maxJumpDistance = 2.0f;
    public float jumpHeight = 1.0f;
    public float maxHoldTime = 2.0f;
    public float proximityRange = 0.5f; // Range to detect if near astronaut
    
    [Header("Trajectory")]
    public LineRenderer trajectoryLine;
    public int trajectoryPoints = 20;
    
    [Header("Audio")]
    public AudioSource audioSource;
    public AudioClip jumpSound;
    
    private Camera arCamera;
    private bool isHolding = false;
    private bool isJumping = false;
    private float holdStartTime;
    private int currentPlanetIndex = 0;
    
    void Start()
    {
        arCamera = Camera.main;
        
        // Create trajectory line if not assigned
        if (trajectoryLine == null)
        {
            GameObject lineObj = new GameObject("Trajectory");
            lineObj.transform.SetParent(transform);
            trajectoryLine = lineObj.AddComponent<LineRenderer>();
            trajectoryLine.startWidth = 0.02f;
            trajectoryLine.endWidth = 0.02f;
            trajectoryLine.positionCount = trajectoryPoints;
            trajectoryLine.material = new Material(Shader.Find("Sprites/Default"));
            trajectoryLine.startColor = Color.yellow;
            trajectoryLine.endColor = Color.red;
        }
        
        // Create audio source if not assigned
        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
            audioSource.playOnAwake = false;
        }
        
        trajectoryLine.enabled = false;
    }
    
    void Update()
    {
        if (GameManager.Instance.currentState != GameManager.GameState.Playing) return;
        if (isJumping) return;
        
        // Check if touching UI
        if (IsTouchingUI()) return;
        
        // Handle input
        bool inputDown = false;
        bool inputHeld = false;
        bool inputUp = false;
        
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            inputDown = touch.phase == TouchPhase.Began;
            inputHeld = touch.phase == TouchPhase.Moved || touch.phase == TouchPhase.Stationary;
            inputUp = touch.phase == TouchPhase.Ended;
        }
        else
        {
            inputDown = Input.GetMouseButtonDown(0);
            inputHeld = Input.GetMouseButton(0);
            inputUp = Input.GetMouseButtonUp(0);
        }
        
        // Start holding (check proximity to astronaut)
        if (inputDown && !isHolding)
        {
            if (IsNearAstronaut())
            {
                isHolding = true;
                holdStartTime = Time.time;
                trajectoryLine.enabled = true;
                Debug.Log("🚀 Started holding near astronaut");
            }
            else
            {
                Debug.Log("⚠️ Touch too far from astronaut. Get closer!");
            }
        }
        
        // Update trajectory while holding
        if (inputHeld && isHolding)
        {
            UpdateTrajectory();
        }
        
        // Jump on release
        if (inputUp && isHolding)
        {
            Jump();
        }
    }
    
    bool IsTouchingUI()
    {
        if (EventSystem.current == null) return false;
        
        if (Input.touchCount > 0)
        {
            return EventSystem.current.IsPointerOverGameObject(Input.GetTouch(0).fingerId);
        }
        else
        {
            return EventSystem.current.IsPointerOverGameObject();
        }
    }
    
    bool IsNearAstronaut()
    {
        // Get input position
        Vector3 inputPos;
        if (Input.touchCount > 0)
        {
            inputPos = Input.GetTouch(0).position;
        }
        else
        {
            inputPos = Input.mousePosition;
        }
        
        // Raycast from input position
        Ray ray = arCamera.ScreenPointToRay(inputPos);
        
        // Check distance from ray to astronaut
        Vector3 astronautPos = transform.position;
        Vector3 rayToAstronaut = astronautPos - ray.origin;
        Vector3 projection = Vector3.Project(rayToAstronaut, ray.direction);
        Vector3 closestPoint = ray.origin + projection;
        
        float distance = Vector3.Distance(astronautPos, closestPoint);
        
        Debug.Log($"Distance from touch to astronaut: {distance}");
        
        return distance < proximityRange;
    }
    
    void UpdateTrajectory()
    {
        float holdTime = Time.time - holdStartTime;
        float distance = Mathf.Lerp(minJumpDistance, maxJumpDistance, Mathf.Clamp01(holdTime / maxHoldTime));
        
        // Jump direction based on phone orientation (camera forward)
        Vector3 forward = arCamera.transform.forward;
        forward.y = 0;
        forward.Normalize();
        
        Vector3 targetPos = transform.position + forward * distance;
        
        // Rotate astronaut to face direction
        if (forward != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(forward);
        }
        
        // Draw curved trajectory
        for (int i = 0; i < trajectoryPoints; i++)
        {
            float t = i / (float)(trajectoryPoints - 1);
            Vector3 point = Vector3.Lerp(transform.position, targetPos, t);
            
            // Curved arc based on jump height
            point.y += jumpHeight * Mathf.Sin(t * Mathf.PI);
            
            trajectoryLine.SetPosition(i, point);
        }
    }
    
    void Jump()
    {
        isHolding = false;
        trajectoryLine.enabled = false;
        
        float holdTime = Time.time - holdStartTime;
        float distance = Mathf.Lerp(minJumpDistance, maxJumpDistance, Mathf.Clamp01(holdTime / maxHoldTime));
        
        Vector3 forward = arCamera.transform.forward;
        forward.y = 0;
        forward.Normalize();
        
        Vector3 targetPos = transform.position + forward * distance;
        
        // Play jump sound
        if (audioSource && jumpSound)
        {
            audioSource.PlayOneShot(jumpSound);
        }
        
        Debug.Log($"🦘 Jumping! Distance: {distance}, Target: {targetPos}");
        
        StartCoroutine(JumpCoroutine(targetPos));
    }
    
    IEnumerator JumpCoroutine(Vector3 target)
    {
        isJumping = true;
        Vector3 start = transform.position;
        float duration = 1.0f;
        float elapsed = 0;
        
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            
            Vector3 pos = Vector3.Lerp(start, target, t);
            pos.y = start.y + jumpHeight * Mathf.Sin(t * Mathf.PI);
            
            transform.position = pos;
            yield return null;
        }
        
        transform.position = target;
        isJumping = false;
        
        CheckLanding();
    }
    
    void CheckLanding()
    {
        bool landed = false;
        float minDistance = float.MaxValue;
        int closestPlanet = -1;
        
        // Find closest planet
        for (int i = 0; i < GameManager.Instance.planets.Count; i++)
        {
            GameObject planet = GameManager.Instance.planets[i];
            Vector3 planetPos = planet.transform.position;
            
            // Check horizontal distance only
            Vector3 astronautFlat = new Vector3(transform.position.x, planetPos.y, transform.position.z);
            float dist = Vector3.Distance(astronautFlat, planetPos);
            
            if (dist < minDistance)
            {
                minDistance = dist;
                closestPlanet = i;
            }
        }
        
        // Check if close enough to land (within planet radius)
        float landingRadius = 0.3f;
        if (minDistance < landingRadius && closestPlanet >= 0)
        {
            landed = true;
            GameObject planet = GameManager.Instance.planets[closestPlanet];
            
            // Snap to planet
            transform.position = planet.transform.position + Vector3.up * 0.3f;
            
            // Mark visited
            GameManager.Instance.MarkPlanetVisited(closestPlanet);
            currentPlanetIndex = closestPlanet;
            
            Debug.Log($"✅ LANDED on planet {closestPlanet}!");
        }
        
        // Missed all planets!
        if (!landed)
        {
            Debug.Log($"❌ MISSED! Closest was {minDistance}m away");
            GameManager.Instance.LoseLife();
            
            // Respawn at last planet
            if (currentPlanetIndex < GameManager.Instance.planets.Count)
            {
                GameObject lastPlanet = GameManager.Instance.planets[currentPlanetIndex];
                transform.position = lastPlanet.transform.position + Vector3.up * 0.3f;
                Debug.Log($"♻️ Respawned at planet {currentPlanetIndex}");
            }
        }
    }
}