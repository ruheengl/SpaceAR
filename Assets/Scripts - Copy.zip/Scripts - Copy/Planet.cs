using UnityEngine;

public class Planet : MonoBehaviour
{
    public int planetIndex = 0;
    
    // This is a simple component to identify planets
    // The index is set by GameManager when creating the planet
}