using UnityEngine;
using UnityEngine.EventSystems;
using Vuforia;

public class PlanetCreator : MonoBehaviour
{
    [Header("Vuforia References")]
    public PlaneFinderBehaviour planeFinder;
    
    [Header("Planet Prefabs")]
    public GameObject[] groundPlanetPrefabs;
    public GameObject[] midAirPlanetPrefabs;
    
    [Header("Mid-Air 'Hold' Settings")]
    public GameObject planetPreview; // This will be our persistent marker
    public float minHoldTime = 0.1f;
    public float planetGrowthRate = 0.1f;
    public float maxPlanetScale = 0.3f;
    public float markerBaseScale = 0.05f; // Base scale for the marker
    public float markerDistance = 1.0f; // Distance marker floats from camera

    private Camera arCamera;
    private bool isCreatingPlanet = false;
    private float holdStartTime;
    private Vector3 planetPosition; // This will be the 'locked' position on touch
    
    private GameObject midAirMarkerInstance; // The persistent marker object
    
    private float finalMidAirScale;
    private bool hasPlacedGroundThisFrame = false; 

    void Start()
    {
        arCamera = Camera.main;
        if (planeFinder != null)
        {
            planeFinder.OnInteractiveHitTest.AddListener(OnGroundPlaneTapped);
        }
        else
        {
            Debug.LogError("PlaneFinder not found!");
        }

        // Create the persistent marker
        if (planetPreview != null)
        {
            midAirMarkerInstance = Instantiate(planetPreview);
            MakePreviewTransparent(midAirMarkerInstance); // Apply transparency settings
            midAirMarkerInstance.SetActive(false); // Hide it until we need it
        }
        else
        {
            Debug.LogError("Planet Preview prefab is NOT assigned in Inspector!");
        }
    }

    void Update()
    {
        if (GameManager.Instance == null) return;

        GameManager.GameState state = GameManager.Instance.currentState;
        
        hasPlacedGroundThisFrame = false;

        if (planeFinder != null)
        {
            planeFinder.enabled = (state == GameManager.GameState.PlacingStart ||
                                   state == GameManager.GameState.PlacingFinish);
        }

        // Marker visibility and positioning logic
        if (state == GameManager.GameState.CreatingPlanets)
        {
            if (midAirMarkerInstance != null)
            {
                midAirMarkerInstance.SetActive(true);

                // Handle the input for scaling/placing
                HandleMidAirPlanetCreation();

                // If we are NOT currently scaling, make the marker follow the camera
                if (!isCreatingPlanet)
                {
                    midAirMarkerInstance.transform.position = arCamera.transform.position + arCamera.transform.forward * markerDistance;
                    midAirMarkerInstance.transform.localScale = Vector3.one * markerBaseScale;
                }
            }
        }
        else
        {
            // If we are not in the planet creation state, hide the marker
            if (midAirMarkerInstance != null)
            {
                midAirMarkerInstance.SetActive(false);
            }
        }
    }

    void OnGroundPlaneTapped(HitTestResult result)
    {
        if (result == null || groundPlanetPrefabs == null) return;
        if (hasPlacedGroundThisFrame) return; 
        
        GameManager.GameState state = GameManager.Instance.currentState;
        
        if (state != GameManager.GameState.PlacingStart && 
            state != GameManager.GameState.PlacingFinish)
        {
            return;
        }

        hasPlacedGroundThisFrame = true;
        Vector3 position = result.Position;
        
        float planetScale = 0.3f;
        
        float planetRadius = planetScale * 0.5f;

        GameObject groundPlanetPrefab = state == GameManager.GameState.PlacingStart ? groundPlanetPrefabs[0] : groundPlanetPrefabs[1];
        GameObject planet = Instantiate(groundPlanetPrefab, position, Quaternion.identity);
        planet.transform.localScale = Vector3.one * planetScale;
        
        AddPlanetComponent(planet);
        PlayPlanetSound();

        Debug.Log("Ground planet created. State: " + state);

        if (state == GameManager.GameState.PlacingStart)
        {
            // 4. Use the calculated radius to set the astronaut's position
            GameManager.Instance.astronaut.transform.position = position + Vector3.up * planetRadius;
            
            GameManager.Instance.currentState = GameManager.GameState.CreatingPlanets;
            Debug.Log("START placed. Now creating mid-air planets.");
        }
        else if (state == GameManager.GameState.PlacingFinish)
        {
            GameManager.Instance.currentState = GameManager.GameState.Playing;
            GameManager.Instance.astronaut.SetActive(true);
            GameManager.Instance.MarkPlanetVisited(0);
            Debug.Log("FINISH placed. Game starting!");
        }
    }

    void HandleMidAirPlanetCreation()
    {
        // UI Check
        // if (IsTouchingUI())
        // {
        //     Debug.Log("Touching UI - ignoring input");
        //     return;
        // }

        // Mouse input (Editor testing)
        if (Input.touchCount == 0)
        {
            if (Input.GetMouseButtonDown(0) && !isCreatingPlanet)
            {
                StartCreatingPlanet();
            }
            else if (Input.GetMouseButton(0) && isCreatingPlanet)
            {
                UpdatePlanetPreview();
            }
            else if (Input.GetMouseButtonUp(0) && isCreatingPlanet)
            {
                FinishCreatingPlanet();
            }
        }
        // Touch input (Device)
        else if (Input.touchCount >= 1)
        {
            Touch touch = Input.GetTouch(0);

            if (touch.phase == TouchPhase.Began && !isCreatingPlanet)
            {
                StartCreatingPlanet();
            }
            else if ((touch.phase == TouchPhase.Moved || touch.phase == TouchPhase.Stationary) && isCreatingPlanet)
            {
                UpdatePlanetPreview();
            }
            else if ((touch.phase == TouchPhase.Ended || touch.phase == TouchPhase.Canceled) && isCreatingPlanet)
            {
                FinishCreatingPlanet();
            }
        }
    }

    bool IsTouchingUI()
    {
        if (EventSystem.current == null)
            return false;
        
        if (Input.touchCount > 0)
        {
            return EventSystem.current.IsPointerOverGameObject(Input.GetTouch(0).fingerId);
        }
        else if (Input.GetMouseButton(0) || Input.GetMouseButtonDown(0))
        {
            return EventSystem.current.IsPointerOverGameObject();
        }
        return false;
    }

    // Helper function to apply transparency to the marker
    void MakePreviewTransparent(GameObject preview)
    {
        Renderer rend = preview.GetComponentInChildren<Renderer>();
        if (rend != null)
        {
            // This assumes your material uses the Standard shader
            // or another shader that supports transparency.
            Color previewColor = rend.material.color;
            previewColor.a = 0.5f; // Semi-transparent
            rend.material.color = previewColor;
            
            // Settings for Standard Shader in Transparent mode
            rend.material.SetFloat("_Mode", 3); // Transparent mode
            rend.material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
            rend.material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            rend.material.SetInt("_ZWrite", 0);
            rend.material.DisableKeyword("_ALPHATEST_ON");
            rend.material.EnableKeyword("_ALPHABLEND_ON");
            rend.material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            rend.material.renderQueue = 3000;
        }
    }

    void StartCreatingPlanet()
    {
        isCreatingPlanet = true;
        holdStartTime = Time.time;
        
        // Lock the position from the marker's current position
        planetPosition = midAirMarkerInstance.transform.position; 
        
        // Set the starting scale
        finalMidAirScale = markerBaseScale;
        midAirMarkerInstance.transform.localScale = Vector3.one * finalMidAirScale;
        
        Debug.Log("✅ Planet creation started at: " + planetPosition);
    }

    void UpdatePlanetPreview()
    {
        // We no longer update the position here, it's locked.
        // We ONLY update the scale of the existing marker.
        if (midAirMarkerInstance != null)
        {
            float holdTime = Time.time - holdStartTime;
            
            // Use markerBaseScale as the starting point
            float scale = Mathf.Min(markerBaseScale + holdTime * planetGrowthRate, maxPlanetScale); 
            
            midAirMarkerInstance.transform.localScale = Vector3.one * scale;
            
            finalMidAirScale = scale;
        }
    }

    void FinishCreatingPlanet()
    {
        float holdTime = Time.time - holdStartTime;
        Debug.Log("Hold time: " + holdTime + " seconds");
        
        if (holdTime >= minHoldTime && midAirPlanetPrefabs != null)
        {
            // Create the *actual* mid-air planet
            GameObject planet = Instantiate(midAirPlanetPrefabs[GameManager.Instance.planets.Count - 1], planetPosition, Quaternion.identity);
            planet.transform.localScale = Vector3.one * finalMidAirScale;

            AddPlanetComponent(planet);
            PlayPlanetSound();
            
            Debug.Log("Mid-air planet created! Total planets: " + GameManager.Instance.planets.Count);
            
            int midAirCount = GameManager.Instance.planets.Count - 1; // -1 for the start planet
            if (midAirCount >= GameManager.Instance.midAirPlanetsNeeded)
            {
                GameManager.Instance.currentState = GameManager.GameState.PlacingFinish;
                Debug.Log("All mid-air planets created. Place FINISH now.");
            }
        }
        else
        {
            Debug.Log("Hold time too short or prefab missing");
        }
        
        // We DO NOT destroy the marker. We just reset the flag.
        isCreatingPlanet = false;
        
        // The Update() loop will now take over and start moving the marker again.
    }

    void AddPlanetComponent(GameObject planet)
    {
        Planet planetScript = planet.AddComponent<Planet>();
        planetScript.planetIndex = GameManager.Instance.planets.Count;
        GameManager.Instance.planets.Add(planet);
    }

    void PlayPlanetSound()
    {
        if (GameManager.Instance.audioSource && GameManager.Instance.planetSound)
        {
            GameManager.Instance.audioSource.PlayOneShot(GameManager.Instance.planetSound);
        }
    }

    void OnDestroy()
    {
        if (planeFinder != null)
        {
            planeFinder.OnInteractiveHitTest.RemoveListener(OnGroundPlaneTapped);
        }
        
        // Clean up the marker if we destroy this object
        if (midAirMarkerInstance != null)
        {
            Destroy(midAirMarkerInstance);
        }
    }
}